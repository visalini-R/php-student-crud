<?php
// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "students_info1";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$uploadDir = "uploads/";
if (!file_exists($uploadDir)) mkdir($uploadDir, 0755);

// CREATE
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $name = $conn->real_escape_string($_POST['a']);
    $age = (int)$_POST['b'];
    $course = $conn->real_escape_string($_POST['c']);

    $imagePath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $filename = uniqid() . "_" . basename($_FILES["image"]["name"]);
        $imagePath = $uploadDir . $filename;
        move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath);
    }

    $sql = "INSERT INTO students (name, age, course, image) VALUES ('$name', $age, '$course', '$imagePath')";
    if ($conn->query($sql) === TRUE) echo "<div class='alert'>Record saved successfully!</div>";
    else echo "<div class='alert error'>Error: " . $conn->error . "</div>";
}

// DELETE
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $res = $conn->query("SELECT image FROM students WHERE id=$id");
    if ($res && $row = $res->fetch_assoc()) {
        if ($row['image'] && file_exists($row['image'])) unlink($row['image']);
    }
    $conn->query("DELETE FROM students WHERE id=$id");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// UPDATE
$editData = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $result = $conn->query("SELECT * FROM students WHERE id=$id");
    $editData = $result->fetch_assoc();
}

if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $name = $conn->real_escape_string($_POST['a']);
    $age = (int)$_POST['b'];
    $course = $conn->real_escape_string($_POST['c']);

    $imagePath = $editData['image'] ?? '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        if ($imagePath && file_exists($imagePath)) unlink($imagePath);
        $filename = uniqid() . "_" . basename($_FILES["image"]["name"]);
        $imagePath = $uploadDir . $filename;
        move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath);
    }

    $sql = "UPDATE students SET name='$name', age=$age, course='$course', image='$imagePath' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    } else echo "<div class='alert error'>Error: " . $conn->error . "</div>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student CRUD with Image</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .header {
            background: #343a40;
            color: #fff;
            padding: 10px 20px;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .nav {
            margin-bottom: 20px;
        }
        .nav a {
            margin-right: 15px;
            text-decoration: none;
            color: #007bff;
        }
        .form-section, .table-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        input, select, textarea {
            padding: 8px;
            width: 100%;
            margin-top: 5px;
            margin-bottom: 15px;
        }
        input[type="submit"] {
            width: auto;
            background: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        .alert {
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            margin-bottom: 15px;
            border: 1px solid #c3e6cb;
        }
        .alert.error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="header">Student Management</div>
    <div class="nav">
        <a href="<?= $_SERVER['PHP_SELF'] ?>">Home</a>
        <a href="#form">Add Student</a>
    </div>

    <div class="form-section" id="form">
        <h2><?= $editData ? "Edit Student" : "Add New Student" ?></h2>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
            Name: <input type="text" name="a" value="<?= $editData['name'] ?? '' ?>" required>
            Age: <input type="number" name="b" value="<?= $editData['age'] ?? '' ?>" required>
            Course: <input type="text" name="c" value="<?= $editData['course'] ?? '' ?>" required>
            Photo: <input type="file" name="image">
            <?php if ($editData && $editData['image']): ?>
                <img src="<?= $editData['image'] ?>" width="100"><br><br>
            <?php endif; ?>
            <input type="submit" name="<?= $editData ? 'update' : 'submit' ?>" value="<?= $editData ? 'Update' : 'Submit' ?>">
        </form>
    </div>

    <div class="table-section">
        <h2>Student Records</h2>
        <table>
            <tr>
                <th>ID</th><th>Name</th><th>Age</th><th>Course</th><th>Image</th><th>Actions</th>
            </tr>
            <?php
            $result = $conn->query("SELECT * FROM students");
            while ($row = $result->fetch_assoc()):
            ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= $row['age'] ?></td>
                <td><?= htmlspecialchars($row['course']) ?></td>
                <td>
                    <?php if ($row['image']): ?>
                        <img src="<?= $row['image'] ?>" width="60">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>">Edit</a> |
                    <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Are you sure to delete?');">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
